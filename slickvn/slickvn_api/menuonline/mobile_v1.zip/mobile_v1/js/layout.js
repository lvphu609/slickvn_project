$(function(){
	//alert('ok');
});